import React from 'react';
import { RobotIcon } from './icons';

export const ThinkingIndicator: React.FC = () => {
  return (
    <div className="flex items-end justify-start">
        <RobotIcon className="w-8 h-8 text-purple-300 mr-3 mb-1 flex-shrink-0" />
        <div className="flex items-center space-x-1 bg-gray-700/70 rounded-2xl rounded-bl-none p-4">
            <div className="w-2 h-2 bg-purple-300 rounded-full animate-pulse [animation-delay:-0.3s]"></div>
            <div className="w-2 h-2 bg-purple-300 rounded-full animate-pulse [animation-delay:-0.15s]"></div>
            <div className="w-2 h-2 bg-purple-300 rounded-full animate-pulse"></div>
        </div>
    </div>
  );
};