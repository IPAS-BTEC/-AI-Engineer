import React, { useState } from 'react';
import { SendIcon } from './icons';

interface UserInputProps {
  onSubmit: (input: string) => void;
  isLoading: boolean;
}

export const UserInput: React.FC<UserInputProps> = ({ onSubmit, isLoading }) => {
  const [inputValue, setInputValue] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputValue.trim() && !isLoading) {
      onSubmit(inputValue);
      setInputValue('');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="flex items-center space-x-3">
      <input
        type="text"
        value={inputValue}
        onChange={(e) => setInputValue(e.target.value)}
        placeholder="اسأل عن محتوى الكتاب..."
        disabled={isLoading}
        className="flex-grow bg-white/10 border border-white/20 rounded-full py-3 px-5 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-400 transition-all duration-300 disabled:opacity-50 shadow-inner"
      />
      <button
        type="submit"
        disabled={isLoading}
        className="btn-3d bg-purple-600 hover:bg-purple-700 disabled:bg-purple-800 disabled:cursor-not-allowed rounded-full p-3 transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-purple-400 focus:ring-offset-2 focus:ring-offset-purple-900"
      >
        <SendIcon className="w-6 h-6 text-white" />
      </button>
    </form>
  );
};