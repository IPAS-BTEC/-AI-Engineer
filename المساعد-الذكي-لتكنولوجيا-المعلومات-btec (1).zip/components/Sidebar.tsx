import React, { useState, useMemo } from 'react';
import { ChatSession } from '../types';
import { PlusIcon, MessageIcon, TrashIcon, SearchIcon } from './icons';

interface SidebarProps {
  sessions: ChatSession[];
  activeSessionId: string | null;
  onNewChat: () => void;
  onSelectSession: (id: string) => void;
  onDeleteSession: (id: string) => void;
  isOpen: boolean;
}

export const Sidebar: React.FC<SidebarProps> = ({ sessions, activeSessionId, onNewChat, onSelectSession, onDeleteSession, isOpen }) => {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredSessions = useMemo(() => {
    if (!searchQuery.trim()) {
      return sessions;
    }
    const lowercasedQuery = searchQuery.toLowerCase();
    return sessions.filter(session =>
      session.title.toLowerCase().includes(lowercasedQuery) ||
      session.messages.some(message => message.content.toLowerCase().includes(lowercasedQuery))
    );
  }, [sessions, searchQuery]);

  return (
    <aside 
      className={`absolute top-0 h-full bg-black/30 backdrop-blur-xl w-64 md:w-72 transform transition-transform duration-300 ease-in-out z-20 md:relative md:translate-x-0 rounded-l-2xl border-l border-white/20 ${
        isOpen ? 'translate-x-0 right-0' : 'translate-x-full right-0'
      } md:h-auto`}
       style={{ right: isOpen ? '0' : '-100%', transformOrigin: 'right center' }}
    >
      <div className="p-4 flex flex-col h-full">
        <button
          onClick={onNewChat}
          className="btn-3d flex items-center justify-center w-full p-3 mb-4 text-white bg-purple-600 rounded-lg hover:bg-purple-700 transition-colors"
        >
          <PlusIcon className="w-5 h-5 ml-2" />
          <span>محادثة جديدة</span>
        </button>

        <div className="relative mb-4">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ابحث في المحادثات..."
            className="w-full bg-white/10 border border-white/20 rounded-lg py-2 pr-10 pl-4 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-400 transition-all duration-300 shadow-inner"
          />
          <div className="absolute top-1/2 right-3 -translate-y-1/2 text-gray-400">
              <SearchIcon className="w-5 h-5" />
          </div>
        </div>

        <nav className="flex-grow overflow-y-auto">
          {filteredSessions.length > 0 ? (
            <ul>
              {filteredSessions.map(session => (
                <li key={session.id} className="relative group">
                  <button
                    onClick={() => onSelectSession(session.id)}
                    className={`w-full text-right p-3 my-1 rounded-md flex items-center transition-all duration-200 transform hover:scale-105 ${
                      activeSessionId === session.id ? 'bg-white/20 shadow-inner' : 'hover:bg-white/10'
                    }`}
                  >
                    <MessageIcon className="w-5 h-5 ml-3 flex-shrink-0" />
                    <span className="truncate flex-grow">{session.title}</span>
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteSession(session.id);
                    }}
                    className="absolute left-2 top-1/2 -translate-y-1/2 p-1.5 rounded-md text-gray-400 hover:bg-red-500/30 hover:text-red-300 opacity-0 group-hover:opacity-100 transition-opacity"
                    title="حذف المحادثة"
                    aria-label="حذف المحادثة"
                  >
                      <TrashIcon className="w-5 h-5" />
                  </button>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-center text-gray-400 mt-4">لا توجد نتائج</p>
          )}
        </nav>
      </div>
    </aside>
  );
};
