import React from 'react';
import { Message } from '../types';
import { UserIcon, RobotIcon } from './icons';

export const ChatBubble: React.FC<Message> = ({ role, content }) => {
  const isUser = role === 'user';

  const bubbleClasses = isUser
    ? 'bg-blue-600/80 rounded-br-none self-end border-t border-l border-blue-400/50'
    : 'bg-gray-700/70 rounded-bl-none self-start border-t border-l border-gray-500/50';

  const containerClasses = isUser
    ? 'flex items-end justify-end'
    : 'flex items-end justify-start';
    
  return (
    <div className={containerClasses}>
      {!isUser && <RobotIcon className="w-8 h-8 text-purple-300 mr-3 mb-1 flex-shrink-0" />}
      <div className={`bubble-3d max-w-xs md:max-w-2xl p-4 rounded-2xl shadow-md ${bubbleClasses}`}>
        <div className="text-base leading-relaxed space-y-2">
           {content.split('\n').map((line, index) => <p key={index}>{line || '\u00A0'}</p>)}
        </div>
      </div>
      {isUser && <UserIcon className="w-8 h-8 text-blue-300 ml-3 mb-1 flex-shrink-0" />}
    </div>
  );
};