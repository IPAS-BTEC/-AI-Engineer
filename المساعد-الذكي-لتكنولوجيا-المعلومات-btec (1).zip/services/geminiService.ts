import { GoogleGenAI, Content } from "@google/genai";
import { BOOK_CONTEXT } from "../constants";
import { Message } from "../types";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });
const model = 'gemini-2.5-flash';

export const askBookQuestion = async (history: Message[]): Promise<string> => {
  const systemInstruction = `
أنت "المساعد الذكي لتكنولوجيا المعلومات BTEC". دورك هو مساعدة المستخدم والإجابة على أسئلته ضمن سياق كتاب "Pearson BTEC International Level 2 in Information Technology (Jordan)".
استخدم النص المرفق من الكتاب كمرجع أساسي وسياق لفهم مواضيع الأسئلة، ولكن لا تقتصر إجاباتك على المعلومات الموجودة فيه فقط.
دورك هو أن تكون مساعدًا تعليميًا خبيرًا، وتشرح المفاهيم بعمق وتقدم أمثلة وتوضيحات إضافية من معرفتك الواسعة في مجال تكنولوجيا المعلومات، مع ضمان بقاء الإجابة دائمًا ضمن سياق المادة الدراسية للمستوى الثاني من BTEC.
كن مستعدًا لفهم الأسئلة باللغة العربية العامية والرد عليها بلغة عربية فصحى وواضحة.
عندما يطلب المستخدم تقريرًا أو خطة أو بيانات منظمة (لبرنامج Word أو Excel على سبيل المثال)، قم بتنسيق إجابتك باستخدام Markdown. استخدم العناوين (#, ##)، والقوائم النقطية (*)، والجداول البسيطة لتقديم معلومات واضحة ومرتبة وسهلة النسخ.
لا تذكر أي معلومات عن حقوق النشر أو المؤلفين أو النشر.
يجب أن تكون إجاباتك باللغة العربية.

النص من الكتاب:
---
${BOOK_CONTEXT}
---
  `;
  
  const welcomeMessage = 'أهلاً بك! أنا المساعد الذكي لتكنولوجيا المعلومات BTEC. أنا هنا لمساعدتك في الإجابة على أسئلتك حول كتاب تكنولوجيا المعلومات للمستوى 2. كيف يمكنني مساعدتك اليوم؟';

  // Format the history for the API, excluding the initial welcome message from the model's perspective.
  const formattedHistory: Content[] = history
    .filter(msg => msg.content !== welcomeMessage)
    .map(msg => ({
      role: msg.role,
      parts: [{ text: msg.content }],
  }));

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: formattedHistory,
      config: {
        systemInstruction: systemInstruction,
      },
    });
    
    return response.text;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Failed to get a response from the AI assistant.");
  }
};