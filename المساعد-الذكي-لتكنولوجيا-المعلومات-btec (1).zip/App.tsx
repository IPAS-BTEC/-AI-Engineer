import React, { useState, useRef, useEffect, useMemo } from 'react';
import { askBookQuestion } from './services/geminiService';
import { ChatBubble } from './components/ChatBubble';
import { UserInput } from './components/UserInput';
import { ThinkingIndicator } from './components/ThinkingIndicator';
import { MenuIcon } from './components/icons';
import { Message, ChatSession } from './types';
import { Sidebar } from './components/Sidebar';

const LOCAL_STORAGE_KEY_SESSIONS = 'btec_chat_sessions';
const LEGACY_LOCAL_STORAGE_KEY = 'btec_chat_history';

const WELCOME_MESSAGE: Message = {
  role: 'model',
  content: 'أهلاً بك! أنا المساعد الذكي لتكنولوجيا المعلومات BTEC. أنا هنا لمساعدتك في الإجابة على أسئلتك حول كتاب تكنولوجيا المعلومات للمستوى 2. كيف يمكنني مساعدتك اليوم؟'
};

const createNewSession = (): ChatSession => ({
  id: Date.now().toString(),
  title: 'محادثة جديدة',
  messages: [WELCOME_MESSAGE],
});


const App: React.FC = () => {
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [isSidebarOpen, setSidebarOpen] = useState(window.innerWidth > 768);

  const chatContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    try {
      // Load sessions from new format
      const savedSessions = localStorage.getItem(LOCAL_STORAGE_KEY_SESSIONS);
      if (savedSessions) {
        const parsedSessions = JSON.parse(savedSessions);
        if (Array.isArray(parsedSessions) && parsedSessions.length > 0) {
          setSessions(parsedSessions);
          setActiveSessionId(parsedSessions[0].id);
          return;
        }
      }

      // If no new sessions, try to migrate from old format
      const legacyChat = localStorage.getItem(LEGACY_LOCAL_STORAGE_KEY);
      if (legacyChat) {
        const parsedLegacy = JSON.parse(legacyChat);
        if (Array.isArray(parsedLegacy) && parsedLegacy.length > 1) {
          const migratedSession: ChatSession = {
            id: Date.now().toString(),
            title: 'محادثة سابقة',
            messages: parsedLegacy,
          };
          setSessions([migratedSession]);
          setActiveSessionId(migratedSession.id);
          localStorage.removeItem(LEGACY_LOCAL_STORAGE_KEY);
          return;
        }
      }

      // If nothing to load or migrate, start a fresh session
      const newSession = createNewSession();
      setSessions([newSession]);
      setActiveSessionId(newSession.id);

    } catch (error) {
      console.error("Failed to load or migrate chat history", error);
      const newSession = createNewSession();
      setSessions([newSession]);
      setActiveSessionId(newSession.id);
    }
  }, []);
  
  useEffect(() => {
    if (sessions.length > 0) {
      try {
        localStorage.setItem(LOCAL_STORAGE_KEY_SESSIONS, JSON.stringify(sessions));
      } catch (error) {
        console.error("Failed to save chat sessions to localStorage", error);
      }
    } else {
        localStorage.removeItem(LOCAL_STORAGE_KEY_SESSIONS);
    }
  }, [sessions]);
  
  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [activeSessionId, sessions, isLoading]);

  const activeSession = useMemo(() => {
    return sessions.find(s => s.id === activeSessionId);
  }, [sessions, activeSessionId]);


  const handleSendMessage = async (userInput: string) => {
    if (!userInput.trim() || !activeSessionId) return;

    const userMessage: Message = { role: 'user', content: userInput };
    
    const currentSession = sessions.find(s => s.id === activeSessionId)!;
    const isNewChat = currentSession.title === 'محادثة جديدة';
    const conversationHistory = [...currentSession.messages, userMessage];

    const updatedSessions = sessions.map(s => 
      s.id === activeSessionId 
        ? { 
            ...s, 
            messages: conversationHistory, 
            title: isNewChat ? userInput.substring(0, 40) + (userInput.length > 40 ? '...' : '') : s.title 
          }
        : s
    );
    setSessions(updatedSessions);

    setError(null);
    setIsLoading(true);

    try {
      const response = await askBookQuestion(conversationHistory);
      const modelMessage: Message = { role: 'model', content: response };
      
      setSessions(prevSessions => prevSessions.map(s => 
          s.id === activeSessionId 
              ? { ...s, messages: [...conversationHistory, modelMessage] }
              : s
      ));

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred.';
      setError(errorMessage);
       const errorResponseMessage: Message = { role: 'model', content: "عذراً، حدث خطأ أثناء محاولة الإجابة. يرجى المحاولة مرة أخرى." };
       setSessions(prevSessions => prevSessions.map(s => 
           s.id === activeSessionId 
               ? { ...s, messages: [...conversationHistory, errorResponseMessage] }
               : s
       ));
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleNewChat = () => {
    const newSession = createNewSession();
    setSessions(prev => [newSession, ...prev]);
    setActiveSessionId(newSession.id);
    if (window.innerWidth < 768) {
        setSidebarOpen(false);
    }
  };

  const handleSelectSession = (id: string) => {
    setActiveSessionId(id);
    if (window.innerWidth < 768) {
        setSidebarOpen(false);
    }
  }
  
  const handleDeleteSession = (sessionId: string) => {
    if (!window.confirm("هل أنت متأكد أنك تريد حذف هذه المحادثة؟ لا يمكن التراجع عن هذا الإجراء.")) {
      return;
    }

    setSessions(prevSessions => {
      const remainingSessions = prevSessions.filter(s => s.id !== sessionId);

      if (activeSessionId === sessionId) {
        if (remainingSessions.length > 0) {
          setActiveSessionId(remainingSessions[0].id);
        } else {
          const newSession = createNewSession();
          setActiveSessionId(newSession.id);
          return [newSession];
        }
      }
      
      return remainingSessions;
    });
  };

  const toggleSidebar = () => setSidebarOpen(!isSidebarOpen);

  return (
    <div className="relative overflow-hidden bg-gradient-to-br from-purple-900 via-blue-800 to-indigo-900 h-screen w-screen flex flex-col font-sans text-white animate-[gradient-animation_15s_ease_infinite] items-center justify-center p-4" style={{ backgroundSize: '200% 200%', perspective: '1500px' }}>
       <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-20 -left-20 w-80 h-80 bg-purple-600/20 rounded-full filter blur-3xl animate-[float-1_20s_ease-in-out_infinite]"></div>
          <div className="absolute -bottom-20 -right-10 w-96 h-96 bg-blue-500/20 rounded-full filter blur-3xl animate-[float-2_25s_ease-in-out_infinite]"></div>
          <div className="absolute top-1/2 left-1/3 w-64 h-64 bg-indigo-500/10 rounded-full filter blur-2xl animate-[float-3_18s_ease-in-out_infinite]"></div>
      </div>

      <div className="relative z-10 flex flex-col h-full w-full md:h-[95vh] md:w-[90vw] md:max-w-6xl rounded-2xl shadow-2xl" style={{ transformStyle: 'preserve-3d' }}>
        <header className="bg-white/10 backdrop-blur-xl p-3 border-b border-white/20 shadow-lg flex items-center justify-between px-4 flex-shrink-0 rounded-t-2xl">
          <h1 className="text-lg md:text-xl font-bold tracking-wider">المساعد الذكي لتكنولوجيا المعلومات BTEC</h1>
          <button
              onClick={toggleSidebar}
              className="md:hidden p-2 rounded-full hover:bg-white/20 transition-colors focus:outline-none focus:ring-2 focus:ring-purple-400"
              aria-label="فتح قائمة المحادثات"
              title="فتح قائمة المحادثات"
          >
              <MenuIcon className="w-6 h-6 text-white" />
          </button>
        </header>
        
        <div className="flex flex-grow overflow-hidden">
            <main className="flex-grow flex flex-col h-full bg-black/10">
                <div ref={chatContainerRef} className="flex-grow p-4 md:p-6 overflow-y-auto space-y-6" style={{ transformStyle: 'preserve-3d' }}>
                    {activeSession?.messages.map((msg, index) => (
                    <ChatBubble key={index} role={msg.role} content={msg.content} />
                    ))}
                    {isLoading && <ThinkingIndicator />}
                    {error && <div className="text-red-400 bg-red-900/50 p-3 rounded-lg">{error}</div>}
                </div>

                <footer className="p-4 bg-white/10 backdrop-blur-xl border-t border-white/20">
                    <div className="w-full max-w-4xl mx-auto">
                        <UserInput onSubmit={handleSendMessage} isLoading={isLoading} />
                    </div>
                </footer>
            </main>
            <Sidebar
                isOpen={isSidebarOpen}
                sessions={sessions}
                activeSessionId={activeSessionId}
                onNewChat={handleNewChat}
                onSelectSession={handleSelectSession}
                onDeleteSession={handleDeleteSession}
            />
        </div>
      </div>
      
      <div className="absolute bottom-4 left-4 z-20 text-xs text-gray-400 text-left">
          <a 
              href="https://www.facebook.com/Ipas.School/?locale=ar_AR" 
              target="_blank" 
              rel="noopener noreferrer"
              className="block text-purple-300 hover:text-purple-200 transition-colors font-semibold"
          >
              IPAS مدارس الاحتراف الدولية
          </a>
          <p>Made by Mohammad Mubaideen</p>
      </div>
    </div>
  );
};

export default App;